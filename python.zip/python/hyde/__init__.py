# HyDE Module
